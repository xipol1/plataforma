const Transaccion = require('../models/Transaccion');
const Anuncio = require('../models/Anuncio');
const Canal = require('../models/Canal');
const User = require('../models/User');
const config = require('../config/config');

// Obtener todas las transacciones (con filtros)
exports.getTransacciones = async (req, res) => {
  try {
    // Construir filtros a partir de query params
    const filtros = {};
    
    // Filtros según el tipo de usuario
    if (req.user.tipo === 'ANUNCIANTE') {
      // Si es anunciante, solo ve sus propias transacciones
      filtros.anuncianteId = req.user.id;
    } else if (req.user.tipo === 'CREADOR') {
      // Si es creador, ve transacciones para sus canales
      filtros.creadorId = req.user.id;
    }
    
    // Filtros adicionales
    if (req.query.estado) filtros.estado = req.query.estado;
    if (req.query.metodoPago) filtros['metodoPago.tipo'] = req.query.metodoPago;
    if (req.query.fechaDesde) {
      filtros.fechaCreacion = { $gte: new Date(req.query.fechaDesde) };
    }
    if (req.query.fechaHasta) {
      if (!filtros.fechaCreacion) filtros.fechaCreacion = {};
      filtros.fechaCreacion.$lte = new Date(req.query.fechaHasta);
    }
    
    // Paginación
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;
    
    // Ordenamiento
    const sort = {};
    if (req.query.sortBy) {
      const parts = req.query.sortBy.split(':');
      sort[parts[0]] = parts[1] === 'desc' ? -1 : 1;
    } else {
      // Ordenamiento por defecto
      sort['fechaCreacion'] = -1;
    }
    
    // Ejecutar consulta
    const transacciones = await Transaccion.find(filtros)
      .populate('anuncioId', 'titulo estado')
      .populate('anuncianteId', 'nombre apellido email')
      .populate('creadorId', 'nombre apellido email')
      .sort(sort)
      .skip(skip)
      .limit(limit);
    
    // Contar total de resultados para paginación
    const total = await Transaccion.countDocuments(filtros);
    
    res.status(200).json({
      success: true,
      count: transacciones.length,
      total,
      pagination: {
        page,
        limit,
        totalPages: Math.ceil(total / limit)
      },
      data: transacciones
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al obtener transacciones',
      error: error.message
    });
  }
};

// Obtener una transacción específica
exports.getTransaccion = async (req, res) => {
  try {
    const transaccion = await Transaccion.findById(req.params.id)
      .populate('anuncioId')
      .populate('anuncianteId', 'nombre apellido email')
      .populate('creadorId', 'nombre apellido email');
    
    if (!transaccion) {
      return res.status(404).json({
        success: false,
        message: 'Transacción no encontrada'
      });
    }
    
    // Verificar permisos
    if (
      req.user.tipo === 'ANUNCIANTE' && transaccion.anuncianteId._id.toString() !== req.user.id ||
      req.user.tipo === 'CREADOR' && transaccion.creadorId._id.toString() !== req.user.id
    ) {
      return res.status(403).json({
        success: false,
        message: 'No tienes permiso para ver esta transacción'
      });
    }
    
    res.status(200).json({
      success: true,
      data: transaccion
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al obtener transacción',
      error: error.message
    });
  }
};

// Crear una nueva transacción
exports.createTransaccion = async (req, res) => {
  try {
    // Verificar que el anuncio existe
    const anuncio = await Anuncio.findById(req.body.anuncioId);
    if (!anuncio) {
      return res.status(404).json({
        success: false,
        message: 'Anuncio no encontrado'
      });
    }
    
    // Verificar que el usuario es el anunciante
    if (req.user.tipo === 'ANUNCIANTE' && anuncio.anuncianteId.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'No tienes permiso para crear una transacción para este anuncio'
      });
    }
    
    // Obtener información del canal y tarifa
    const canal = await Canal.findById(anuncio.canalId);
    if (!canal) {
      return res.status(404).json({
        success: false,
        message: 'Canal no encontrado'
      });
    }
    
    // Calcular comisión y monto neto
    const monto = req.body.monto || 0;
    const comision = monto * config.PLATFORM_COMMISSION_RATE;
    const montoNeto = monto - comision;
    
    // Crear la transacción
    const transaccion = await Transaccion.create({
      anuncioId: anuncio._id,
      anuncianteId: anuncio.anuncianteId,
      creadorId: canal.creadorId,
      monto,
      comision,
      montoNeto,
      moneda: req.body.moneda || 'USD',
      estado: 'PENDIENTE',
      metodoPago: req.body.metodoPago,
      referenciaPago: req.body.referenciaPago,
      metadatosPasarela: req.body.metadatosPasarela
    });
    
    res.status(201).json({
      success: true,
      message: 'Transacción creada exitosamente',
      data: transaccion
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al crear transacción',
      error: error.message
    });
  }
};

// Actualizar estado de una transacción
exports.updateEstadoTransaccion = async (req, res) => {
  try {
    // Verificar que la transacción existe
    let transaccion = await Transaccion.findById(req.params.id);
    
    if (!transaccion) {
      return res.status(404).json({
        success: false,
        message: 'Transacción no encontrada'
      });
    }
    
    // Verificar permisos (solo administradores pueden actualizar estados)
    if (req.user.tipo !== 'ADMINISTRADOR') {
      return res.status(403).json({
        success: false,
        message: 'No tienes permiso para actualizar el estado de esta transacción'
      });
    }
    
    // Verificar que se proporcionó un estado válido
    const estadosValidos = ['PENDIENTE', 'RETENIDO', 'COMPLETADO', 'REEMBOLSADO', 'FALLIDO'];
    if (!estadosValidos.includes(req.body.estado)) {
      return res.status(400).json({
        success: false,
        message: 'Estado no válido'
      });
    }
    
    // Actualizar estado
    transaccion.estado = req.body.estado;
    transaccion.fechaActualizacion = new Date();
    
    // Si se proporcionó un comprobante, actualizarlo
    if (req.body.comprobante) {
      transaccion.comprobante = req.body.comprobante;
    }
    
    // Si se proporcionaron notas internas, actualizarlas
    if (req.body.notasInternas) {
      transaccion.notasInternas = req.body.notasInternas;
    }
    
    await transaccion.save();
    
    // Si la transacción se completó, actualizar el anuncio si es necesario
    if (req.body.estado === 'COMPLETADO') {
      const anuncio = await Anuncio.findById(transaccion.anuncioId);
      if (anuncio && anuncio.estado === 'PUBLICADO') {
        anuncio.estado = 'COMPLETADO';
        await anuncio.save();
      }
    }
    
    res.status(200).json({
      success: true,
      message: 'Estado de transacción actualizado exitosamente',
      data: transaccion
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al actualizar estado de transacción',
      error: error.message
    });
  }
};

// Solicitar retiro de fondos
exports.solicitarRetiro = async (req, res) => {
  try {
    // Verificar que el usuario es creador
    if (req.user.tipo !== 'CREADOR') {
      return res.status(403).json({
        success: false,
        message: 'Solo los creadores pueden solicitar retiros'
      });
    }
    
    // Verificar que se proporcionó un método de pago
    if (!req.body.metodoPago) {
      return res.status(400).json({
        success: false,
        message: 'Debes proporcionar un método de pago'
      });
    }
    
    // Verificar que se proporcionó un monto
    if (!req.body.monto || req.body.monto <= 0) {
      return res.status(400).json({
        success: false,
        message: 'Debes proporcionar un monto válido'
      });
    }
    
    // Calcular saldo disponible
    const transaccionesCompletadas = await Transaccion.find({
      creadorId: req.user.id,
      estado: 'COMPLETADO'
    });
    
    const transaccionesRetiradas = await Transaccion.find({
      creadorId: req.user.id,
      estado: 'RETENIDO',
      notasInternas: /retiro/i
    });
    
    const saldoTotal = transaccionesCompletadas.reduce((total, t) => total + t.montoNeto, 0);
    const saldoRetirado = transaccionesRetiradas.reduce((total, t) => total + t.monto, 0);
    const saldoDisponible = saldoTotal - saldoRetirado;
    
    // Verificar que hay saldo suficiente
    if (req.body.monto > saldoDisponible) {
      return res.status(400).json({
        success: false,
        message: 'Saldo insuficiente',
        data: {
          saldoDisponible,
          montoSolicitado: req.body.monto
        }
      });
    }
    
    // Crear transacción de retiro
    const transaccion = await Transaccion.create({
      anuncioId: null, // No está asociado a un anuncio específico
      anuncianteId: null, // No hay anunciante
      creadorId: req.user.id,
      monto: req.body.monto,
      comision: 0, // No hay comisión en retiros
      montoNeto: req.body.monto,
      moneda: req.body.moneda || 'USD',
      estado: 'PENDIENTE',
      metodoPago: req.body.metodoPago,
      notasInternas: 'Solicitud de retiro'
    });
    
    res.status(201).json({
      success: true,
      message: 'Solicitud de retiro creada exitosamente',
      data: {
        transaccion,
        saldoDisponible: saldoDisponible - req.body.monto
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al solicitar retiro',
      error: error.message
    });
  }
};

// Obtener saldo
exports.getSaldo = async (req, res) => {
  try {
    // Verificar que el usuario es creador o anunciante
    if (req.user.tipo !== 'CREADOR' && req.user.tipo !== 'ANUNCIANTE') {
      return res.status(403).json({
        success: false,
        message: 'No tienes permiso para ver saldos'
      });
    }
    
    let saldoTotal = 0;
    let saldoRetirado = 0;
    let saldoPendiente = 0;
    
    if (req.user.tipo === 'CREADOR') {
      // Calcular saldo para creadores
      const transaccionesCompletadas = await Transaccion.find({
        creadorId: req.user.id,
        estado: 'COMPLETADO'
      });
      
      const transaccionesRetiradas = await Transaccion.find({
        creadorId: req.user.id,
        estado: 'RETENIDO',
        notasInternas: /retiro/i
      });
      
      const transaccionesPendientes = await Transaccion.find({
        creadorId: req.user.id,
        estado: 'PENDIENTE'
      });
      
      saldoTotal = transaccionesCompletadas.reduce((total, t) => total + t.montoNeto, 0);
      saldoRetirado = transaccionesRetiradas.reduce((total, t) => total + t.monto, 0);
      saldoPendiente = transaccionesPendientes.reduce((total, t) => total + t.montoNeto, 0);
    } else {
      // Calcular gastos para anunciantes
      const transaccionesCompletadas = await Transaccion.find({
        anuncianteId: req.user.id,
        estado: 'COMPLETADO'
      });
      
      const transaccionesPendientes = await Transaccion.find({
        anuncianteId: req.user.id,
        estado: 'PENDIENTE'
      });
      
      saldoTotal = transaccionesCompletadas.reduce((total, t) => total + t.monto, 0);
      saldoPendiente = transaccionesPendientes.reduce((total, t) => total + t.monto, 0);
    }
    
    res.status(200).json({
      success: true,
      data: {
        saldoTotal,
        saldoRetirado,
        saldoPendiente,
        saldoDisponible: saldoTotal - saldoRetirado
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al obtener saldo',
      error: error.message
    });
  }
};

// Listar métodos de pago
exports.getMetodosPago = async (req, res) => {
  try {
    // Obtener usuario con métodos de pago
    const user = await User.findById(req.user.id).select('metodosPago');
    
    res.status(200).json({
      success: true,
      data: user.metodosPago
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al obtener métodos de pago',
      error: error.message
    });
  }
};

// Añadir método de pago
exports.addMetodoPago = async (req, res) => {
  try {
    // Verificar que se proporcionaron los datos necesarios
    if (!req.body.tipo || !req.body.detalles) {
      return res.status(400).json({
        success: false,
        message: 'Debes proporcionar tipo y detalles del método de pago'
      });
    }
    
    // Verificar que el tipo es válido
    const tiposValidos = ['TARJETA', 'PAYPAL', 'TRANSFERENCIA', 'CRIPTO'];
    if (!tiposValidos.includes(req.body.tipo)) {
      return res.status(400).json({
        success: false,
        message: 'Tipo de método de pago no válido'
      });
    }
    
    // Obtener usuario
    const user = await User.findById(req.user.id);
    
    // Añadir método de pago
    user.metodosPago.push({
      tipo: req.body.tipo,
      detalles: req.body.detalles,
      predeterminado: req.body.predeterminado || false
    });
    
    // Si es predeterminado, actualizar los demás
    if (req.body.predeterminado) {
      user.metodosPago.forEach((metodo, index) => {
        if (index !== user.metodosPago.length - 1) {
          metodo.predeterminado = false;
        }
      });
    }
    
    await user.save();
    
    res.status(201).json({
      success: true,
      message: 'Método de pago añadido exitosamente',
      data: user.metodosPago
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al añadir método de pago',
      error: error.message
    });
  }
};

// Eliminar método de pago
exports.deleteMetodoPago = async (req, res) => {
  try {
    // Obtener usuario
    const user = await User.findById(req.user.id);
    
    // Verificar que el método de pago existe
    if (!user.metodosPago.id(req.params.id)) {
      return res.status(404).json({
        success: false,
        message: 'Método de pago no encontrado'
      });
    }
    
    // Eliminar método de pago
    user.metodosPago.id(req.params.id).remove();
    await user.save();
    
    res.status(200).json({
      success: true,
      message: 'Método de pago eliminado exitosamente',
      data: user.metodosPago
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al eliminar método de pago',
      error: error.message
    });
  }
};
