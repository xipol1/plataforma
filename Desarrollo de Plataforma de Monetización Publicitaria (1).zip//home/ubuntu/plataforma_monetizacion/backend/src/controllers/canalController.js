const Canal = require('../models/Canal');
const Tarifa = require('../models/Tarifa');
const Estadistica = require('../models/Estadistica');

// Obtener todos los canales (con filtros)
exports.getCanales = async (req, res) => {
  try {
    // Construir filtros a partir de query params
    const filtros = {};
    
    // Filtros básicos
    if (req.query.plataforma) filtros.plataforma = req.query.plataforma;
    if (req.query.categoria) filtros.categoria = req.query.categoria;
    if (req.query.estado) filtros.estado = req.query.estado;
    if (req.query.verificado) filtros.verificado = req.query.verificado === 'true';
    
    // Filtros de audiencia
    if (req.query.audienciaMinima) {
      filtros['audiencia.tamano'] = { $gte: parseInt(req.query.audienciaMinima) };
    }
    
    if (req.query.ubicacion) {
      filtros['audiencia.ubicacion'] = req.query.ubicacion;
    }
    
    // Filtros avanzados (solo para búsquedas específicas)
    if (req.query.creadorId) filtros.creadorId = req.query.creadorId;
    
    // Paginación
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;
    
    // Ordenamiento
    const sort = {};
    if (req.query.sortBy) {
      const parts = req.query.sortBy.split(':');
      sort[parts[0]] = parts[1] === 'desc' ? -1 : 1;
    } else {
      // Ordenamiento por defecto
      sort['createdAt'] = -1;
    }
    
    // Ejecutar consulta
    const canales = await Canal.find(filtros)
      .sort(sort)
      .skip(skip)
      .limit(limit);
    
    // Contar total de resultados para paginación
    const total = await Canal.countDocuments(filtros);
    
    res.status(200).json({
      success: true,
      count: canales.length,
      total,
      pagination: {
        page,
        limit,
        totalPages: Math.ceil(total / limit)
      },
      data: canales
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al obtener canales',
      error: error.message
    });
  }
};

// Obtener un canal específico
exports.getCanal = async (req, res) => {
  try {
    const canal = await Canal.findById(req.params.id);
    
    if (!canal) {
      return res.status(404).json({
        success: false,
        message: 'Canal no encontrado'
      });
    }
    
    // Obtener tarifas asociadas al canal
    const tarifas = await Tarifa.find({ canalId: canal._id });
    
    // Obtener estadísticas recientes
    const estadisticas = await Estadistica.find({
      entidadId: canal._id,
      tipoEntidad: 'CANAL'
    }).sort({ 'periodo.fin': -1 }).limit(1);
    
    res.status(200).json({
      success: true,
      data: {
        canal,
        tarifas,
        estadisticas: estadisticas.length > 0 ? estadisticas[0] : null
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al obtener canal',
      error: error.message
    });
  }
};

// Crear un nuevo canal
exports.createCanal = async (req, res) => {
  try {
    // Asignar el creador al usuario actual
    req.body.creadorId = req.user.id;
    
    // Crear el canal
    const canal = await Canal.create(req.body);
    
    res.status(201).json({
      success: true,
      message: 'Canal creado exitosamente',
      data: canal
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al crear canal',
      error: error.message
    });
  }
};

// Actualizar un canal
exports.updateCanal = async (req, res) => {
  try {
    // Verificar que el canal existe
    let canal = await Canal.findById(req.params.id);
    
    if (!canal) {
      return res.status(404).json({
        success: false,
        message: 'Canal no encontrado'
      });
    }
    
    // Verificar que el usuario es el propietario del canal
    if (canal.creadorId.toString() !== req.user.id && req.user.tipo !== 'ADMINISTRADOR') {
      return res.status(403).json({
        success: false,
        message: 'No tienes permiso para actualizar este canal'
      });
    }
    
    // Campos que no se pueden actualizar directamente
    const restrictedFields = ['creadorId', 'verificado', 'fechaVerificacion'];
    
    // Filtrar campos restringidos
    const filteredBody = Object.keys(req.body).reduce((obj, key) => {
      if (!restrictedFields.includes(key)) {
        obj[key] = req.body[key];
      }
      return obj;
    }, {});
    
    // Actualizar canal
    canal = await Canal.findByIdAndUpdate(
      req.params.id,
      filteredBody,
      {
        new: true,
        runValidators: true
      }
    );
    
    res.status(200).json({
      success: true,
      message: 'Canal actualizado exitosamente',
      data: canal
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al actualizar canal',
      error: error.message
    });
  }
};

// Eliminar un canal
exports.deleteCanal = async (req, res) => {
  try {
    // Verificar que el canal existe
    const canal = await Canal.findById(req.params.id);
    
    if (!canal) {
      return res.status(404).json({
        success: false,
        message: 'Canal no encontrado'
      });
    }
    
    // Verificar que el usuario es el propietario del canal
    if (canal.creadorId.toString() !== req.user.id && req.user.tipo !== 'ADMINISTRADOR') {
      return res.status(403).json({
        success: false,
        message: 'No tienes permiso para eliminar este canal'
      });
    }
    
    // Eliminar tarifas asociadas
    await Tarifa.deleteMany({ canalId: canal._id });
    
    // Eliminar canal
    await Canal.findByIdAndDelete(req.params.id);
    
    res.status(200).json({
      success: true,
      message: 'Canal eliminado exitosamente'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al eliminar canal',
      error: error.message
    });
  }
};

// Iniciar proceso de verificación de canal
exports.iniciarVerificacion = async (req, res) => {
  try {
    // Verificar que el canal existe
    const canal = await Canal.findById(req.params.id);
    
    if (!canal) {
      return res.status(404).json({
        success: false,
        message: 'Canal no encontrado'
      });
    }
    
    // Verificar que el usuario es el propietario del canal
    if (canal.creadorId.toString() !== req.user.id && req.user.tipo !== 'ADMINISTRADOR') {
      return res.status(403).json({
        success: false,
        message: 'No tienes permiso para verificar este canal'
      });
    }
    
    // Verificar que el canal no esté ya verificado
    if (canal.verificado) {
      return res.status(400).json({
        success: false,
        message: 'Este canal ya está verificado'
      });
    }
    
    // Actualizar estado del canal
    canal.estado = 'PENDIENTE';
    await canal.save();
    
    // Aquí se implementaría la lógica para iniciar el proceso de verificación
    // Por ejemplo, generar un código único para que el creador lo publique en su canal
    
    res.status(200).json({
      success: true,
      message: 'Proceso de verificación iniciado',
      data: {
        canal,
        // Aquí se incluiría información sobre los siguientes pasos para la verificación
        siguientesPasos: [
          'Publicar el código de verificación en tu canal',
          'Esperar a que nuestro equipo revise la publicación',
          'Una vez verificado, tu canal aparecerá como verificado en la plataforma'
        ]
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al iniciar verificación',
      error: error.message
    });
  }
};

// Obtener estadísticas de un canal
exports.getEstadisticas = async (req, res) => {
  try {
    // Verificar que el canal existe
    const canal = await Canal.findById(req.params.id);
    
    if (!canal) {
      return res.status(404).json({
        success: false,
        message: 'Canal no encontrado'
      });
    }
    
    // Verificar que el usuario tiene permiso para ver las estadísticas
    if (canal.creadorId.toString() !== req.user.id && req.user.tipo !== 'ADMINISTRADOR') {
      return res.status(403).json({
        success: false,
        message: 'No tienes permiso para ver las estadísticas de este canal'
      });
    }
    
    // Obtener parámetros de filtro
    const { desde, hasta } = req.query;
    const filtro = {
      entidadId: canal._id,
      tipoEntidad: 'CANAL'
    };
    
    if (desde && hasta) {
      filtro['periodo.inicio'] = { $gte: new Date(desde) };
      filtro['periodo.fin'] = { $lte: new Date(hasta) };
    }
    
    // Obtener estadísticas
    const estadisticas = await Estadistica.find(filtro).sort({ 'periodo.inicio': -1 });
    
    res.status(200).json({
      success: true,
      count: estadisticas.length,
      data: estadisticas
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al obtener estadísticas',
      error: error.message
    });
  }
};

// Añadir una tarifa a un canal
exports.addTarifa = async (req, res) => {
  try {
    // Verificar que el canal existe
    const canal = await Canal.findById(req.params.id);
    
    if (!canal) {
      return res.status(404).json({
        success: false,
        message: 'Canal no encontrado'
      });
    }
    
    // Verificar que el usuario es el propietario del canal
    if (canal.creadorId.toString() !== req.user.id && req.user.tipo !== 'ADMINISTRADOR') {
      return res.status(403).json({
        success: false,
        message: 'No tienes permiso para añadir tarifas a este canal'
      });
    }
    
    // Asignar el canal a la tarifa
    req.body.canalId = canal._id;
    
    // Crear la tarifa
    const tarifa = await Tarifa.create(req.body);
    
    res.status(201).json({
      success: true,
      message: 'Tarifa añadida exitosamente',
      data: tarifa
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al añadir tarifa',
      error: error.message
    });
  }
};

// Actualizar una tarifa
exports.updateTarifa = async (req, res) => {
  try {
    // Verificar que la tarifa existe
    let tarifa = await Tarifa.findById(req.params.tarifaId);
    
    if (!tarifa) {
      return res.status(404).json({
        success: false,
        message: 'Tarifa no encontrada'
      });
    }
    
    // Verificar que la tarifa pertenece al canal
    if (tarifa.canalId.toString() !== req.params.id) {
      return res.status(400).json({
        success: false,
        message: 'La tarifa no pertenece a este canal'
      });
    }
    
    // Verificar que el usuario es el propietario del canal
    const canal = await Canal.findById(req.params.id);
    
    if (canal.creadorId.toString() !== req.user.id && req.user.tipo !== 'ADMINISTRADOR') {
      return res.status(403).json({
        success: false,
        message: 'No tienes permiso para actualizar esta tarifa'
      });
    }
    
    // Actualizar tarifa
    tarifa = await Tarifa.findByIdAndUpdate(
      req.params.tarifaId,
      req.body,
      {
        new: true,
        runValidators: true
      }
    );
    
    res.status(200).json({
      success: true,
      message: 'Tarifa actualizada exitosamente',
      data: tarifa
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al actualizar tarifa',
      error: error.message
    });
  }
};

// Eliminar una tarifa
exports.deleteTarifa = async (req, res) => {
  try {
    // Verificar que la tarifa existe
    const tarifa = await Tarifa.findById(req.params.tarifaId);
    
    if (!tarifa) {
      return res.status(404).json({
        success: false,
        message: 'Tarifa no encontrada'
      });
    }
    
    // Verificar que la tarifa pertenece al canal
    if (tarifa.canalId.toString() !== req.params.id) {
      return res.status(400).json({
        success: false,
        message: 'La tarifa no pertenece a este canal'
      });
    }
    
    // Verificar que el usuario es el propietario del canal
    const canal = await Canal.findById(req.params.id);
    
    if (canal.creadorId.toString() !== req.user.id && req.user.tipo !== 'ADMINISTRADOR') {
      return res.status(403).json({
        success: false,
        message: 'No tienes permiso para eliminar esta tarifa'
      });
    }
    
    // Eliminar tarifa
    await Tarifa.findByIdAndDelete(req.params.tarifaId);
    
    res.status(200).json({
      success: true,
      message: 'Tarifa eliminada exitosamente'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al eliminar tarifa',
      error: error.message
    });
  }
};
