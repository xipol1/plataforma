const User = require('../models/User');
const jwt = require('jsonwebtoken');
const config = require('../config/config');

// Generar token JWT
const generateToken = (id) => {
  return jwt.sign({ id }, config.JWT_SECRET, {
    expiresIn: config.JWT_EXPIRES_IN
  });
};

// Registrar un nuevo usuario
exports.register = async (req, res) => {
  try {
    const { email, password, nombre, apellido, telefono, pais, idioma, tipo } = req.body;

    // Verificar si el usuario ya existe
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'El correo electrónico ya está registrado'
      });
    }

    // Crear nuevo usuario
    const user = await User.create({
      email,
      password,
      nombre,
      apellido,
      telefono,
      pais,
      idioma,
      tipo: tipo || 'ANUNCIANTE' // Por defecto es anunciante
    });

    // Generar token
    const token = generateToken(user._id);

    // Responder sin incluir la contraseña
    user.password = undefined;

    res.status(201).json({
      success: true,
      message: 'Usuario registrado exitosamente',
      data: {
        user,
        token
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al registrar usuario',
      error: error.message
    });
  }
};

// Iniciar sesión
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    // Verificar si se proporcionaron email y password
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Por favor proporciona email y contraseña'
      });
    }

    // Buscar usuario y verificar contraseña
    const user = await User.findOne({ email });
    
    if (!user || !(await user.comparePassword(password))) {
      return res.status(401).json({
        success: false,
        message: 'Email o contraseña incorrectos'
      });
    }

    // Verificar si el usuario está activo
    if (user.estado !== 'ACTIVO') {
      return res.status(401).json({
        success: false,
        message: 'Tu cuenta no está activa. Contacta al soporte.'
      });
    }

    // Generar token
    const token = generateToken(user._id);

    // Responder sin incluir la contraseña
    user.password = undefined;

    res.status(200).json({
      success: true,
      message: 'Inicio de sesión exitoso',
      data: {
        user,
        token
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al iniciar sesión',
      error: error.message
    });
  }
};

// Obtener perfil del usuario actual
exports.getMe = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'Usuario no encontrado'
      });
    }

    // Responder sin incluir la contraseña
    user.password = undefined;

    res.status(200).json({
      success: true,
      data: {
        user
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al obtener perfil',
      error: error.message
    });
  }
};

// Actualizar perfil del usuario
exports.updateMe = async (req, res) => {
  try {
    // Campos que no se pueden actualizar
    const restrictedFields = ['password', 'email', 'tipo', 'estado'];
    
    // Filtrar campos restringidos
    const filteredBody = Object.keys(req.body).reduce((obj, key) => {
      if (!restrictedFields.includes(key)) {
        obj[key] = req.body[key];
      }
      return obj;
    }, {});

    // Actualizar usuario
    const updatedUser = await User.findByIdAndUpdate(
      req.user.id,
      filteredBody,
      {
        new: true,
        runValidators: true
      }
    );

    // Responder sin incluir la contraseña
    updatedUser.password = undefined;

    res.status(200).json({
      success: true,
      message: 'Perfil actualizado exitosamente',
      data: {
        user: updatedUser
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al actualizar perfil',
      error: error.message
    });
  }
};

// Cambiar contraseña
exports.updatePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;

    // Verificar si se proporcionaron las contraseñas
    if (!currentPassword || !newPassword) {
      return res.status(400).json({
        success: false,
        message: 'Por favor proporciona la contraseña actual y la nueva'
      });
    }

    // Buscar usuario
    const user = await User.findById(req.user.id);

    // Verificar contraseña actual
    if (!(await user.comparePassword(currentPassword))) {
      return res.status(401).json({
        success: false,
        message: 'Contraseña actual incorrecta'
      });
    }

    // Actualizar contraseña
    user.password = newPassword;
    await user.save();

    // Generar nuevo token
    const token = generateToken(user._id);

    // Responder sin incluir la contraseña
    user.password = undefined;

    res.status(200).json({
      success: true,
      message: 'Contraseña actualizada exitosamente',
      data: {
        user,
        token
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al actualizar contraseña',
      error: error.message
    });
  }
};

// Solicitar restablecimiento de contraseña
exports.forgotPassword = async (req, res) => {
  try {
    const { email } = req.body;

    // Verificar si se proporcionó email
    if (!email) {
      return res.status(400).json({
        success: false,
        message: 'Por favor proporciona tu email'
      });
    }

    // Buscar usuario
    const user = await User.findOne({ email });
    
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'No existe un usuario con ese email'
      });
    }

    // Generar token de restablecimiento
    const resetToken = user.createPasswordResetToken();
    await user.save({ validateBeforeSave: false });

    // Aquí se enviaría el email con el token
    // Por simplicidad, solo devolvemos el token en la respuesta
    // En producción, esto se enviaría por email y no se devolvería en la respuesta

    res.status(200).json({
      success: true,
      message: 'Token de restablecimiento enviado al email',
      data: {
        resetToken
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al solicitar restablecimiento de contraseña',
      error: error.message
    });
  }
};

// Restablecer contraseña
exports.resetPassword = async (req, res) => {
  try {
    const { token, newPassword } = req.body;

    // Verificar si se proporcionaron token y nueva contraseña
    if (!token || !newPassword) {
      return res.status(400).json({
        success: false,
        message: 'Por favor proporciona el token y la nueva contraseña'
      });
    }

    // Buscar usuario con el token
    const hashedToken = crypto
      .createHash('sha256')
      .update(token)
      .digest('hex');

    const user = await User.findOne({
      resetPasswordToken: hashedToken,
      resetPasswordExpire: { $gt: Date.now() }
    });

    if (!user) {
      return res.status(400).json({
        success: false,
        message: 'Token inválido o expirado'
      });
    }

    // Actualizar contraseña
    user.password = newPassword;
    user.resetPasswordToken = undefined;
    user.resetPasswordExpire = undefined;
    await user.save();

    // Generar nuevo token
    const jwtToken = generateToken(user._id);

    // Responder sin incluir la contraseña
    user.password = undefined;

    res.status(200).json({
      success: true,
      message: 'Contraseña restablecida exitosamente',
      data: {
        user,
        token: jwtToken
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al restablecer contraseña',
      error: error.message
    });
  }
};