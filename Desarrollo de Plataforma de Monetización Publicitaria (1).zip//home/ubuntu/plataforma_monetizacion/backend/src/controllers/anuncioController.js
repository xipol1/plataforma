const Anuncio = require('../models/Anuncio');
const Canal = require('../models/Canal');
const Tarifa = require('../models/Tarifa');
const Transaccion = require('../models/Transaccion');
const Estadistica = require('../models/Estadistica');

// Obtener todos los anuncios (con filtros)
exports.getAnuncios = async (req, res) => {
  try {
    // Construir filtros a partir de query params
    const filtros = {};
    
    // Filtros según el tipo de usuario
    if (req.user.tipo === 'ANUNCIANTE') {
      // Si es anunciante, solo ve sus propios anuncios
      filtros.anuncianteId = req.user.id;
    } else if (req.user.tipo === 'CREADOR') {
      // Si es creador, ve anuncios para sus canales
      const canales = await Canal.find({ creadorId: req.user.id });
      const canalesIds = canales.map(canal => canal._id);
      filtros.canalId = { $in: canalesIds };
    }
    
    // Filtros adicionales
    if (req.query.estado) filtros.estado = req.query.estado;
    if (req.query.canalId) filtros.canalId = req.query.canalId;
    if (req.query.fechaDesde) {
      filtros.fechaCreacion = { $gte: new Date(req.query.fechaDesde) };
    }
    if (req.query.fechaHasta) {
      if (!filtros.fechaCreacion) filtros.fechaCreacion = {};
      filtros.fechaCreacion.$lte = new Date(req.query.fechaHasta);
    }
    
    // Paginación
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;
    
    // Ordenamiento
    const sort = {};
    if (req.query.sortBy) {
      const parts = req.query.sortBy.split(':');
      sort[parts[0]] = parts[1] === 'desc' ? -1 : 1;
    } else {
      // Ordenamiento por defecto
      sort['fechaCreacion'] = -1;
    }
    
    // Ejecutar consulta
    const anuncios = await Anuncio.find(filtros)
      .populate('canalId', 'nombre plataforma')
      .populate('tarifaId', 'tipoAnuncio precio moneda')
      .sort(sort)
      .skip(skip)
      .limit(limit);
    
    // Contar total de resultados para paginación
    const total = await Anuncio.countDocuments(filtros);
    
    res.status(200).json({
      success: true,
      count: anuncios.length,
      total,
      pagination: {
        page,
        limit,
        totalPages: Math.ceil(total / limit)
      },
      data: anuncios
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al obtener anuncios',
      error: error.message
    });
  }
};

// Obtener un anuncio específico
exports.getAnuncio = async (req, res) => {
  try {
    const anuncio = await Anuncio.findById(req.params.id)
      .populate('anuncianteId', 'nombre apellido email')
      .populate('canalId', 'nombre plataforma audiencia')
      .populate('tarifaId');
    
    if (!anuncio) {
      return res.status(404).json({
        success: false,
        message: 'Anuncio no encontrado'
      });
    }
    
    // Verificar permisos
    if (
      req.user.tipo === 'ANUNCIANTE' && anuncio.anuncianteId._id.toString() !== req.user.id ||
      req.user.tipo === 'CREADOR'
    ) {
      const canal = await Canal.findById(anuncio.canalId);
      if (canal.creadorId.toString() !== req.user.id) {
        return res.status(403).json({
          success: false,
          message: 'No tienes permiso para ver este anuncio'
        });
      }
    }
    
    // Obtener transacción asociada
    const transaccion = await Transaccion.findOne({ anuncioId: anuncio._id });
    
    // Obtener estadísticas
    const estadisticas = await Estadistica.find({
      entidadId: anuncio._id,
      tipoEntidad: 'ANUNCIO'
    }).sort({ 'periodo.fin': -1 }).limit(1);
    
    res.status(200).json({
      success: true,
      data: {
        anuncio,
        transaccion,
        estadisticas: estadisticas.length > 0 ? estadisticas[0] : null
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al obtener anuncio',
      error: error.message
    });
  }
};

// Crear un nuevo anuncio
exports.createAnuncio = async (req, res) => {
  try {
    // Verificar que el usuario es anunciante
    if (req.user.tipo !== 'ANUNCIANTE' && req.user.tipo !== 'ADMINISTRADOR') {
      return res.status(403).json({
        success: false,
        message: 'Solo los anunciantes pueden crear anuncios'
      });
    }
    
    // Verificar que el canal y la tarifa existen
    const canal = await Canal.findById(req.body.canalId);
    if (!canal) {
      return res.status(404).json({
        success: false,
        message: 'Canal no encontrado'
      });
    }
    
    const tarifa = await Tarifa.findById(req.body.tarifaId);
    if (!tarifa) {
      return res.status(404).json({
        success: false,
        message: 'Tarifa no encontrada'
      });
    }
    
    // Verificar que la tarifa pertenece al canal
    if (tarifa.canalId.toString() !== canal._id.toString()) {
      return res.status(400).json({
        success: false,
        message: 'La tarifa no pertenece a este canal'
      });
    }
    
    // Asignar el anunciante al usuario actual
    req.body.anuncianteId = req.user.id;
    
    // Crear el anuncio
    const anuncio = await Anuncio.create(req.body);
    
    res.status(201).json({
      success: true,
      message: 'Anuncio creado exitosamente',
      data: anuncio
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al crear anuncio',
      error: error.message
    });
  }
};

// Actualizar un anuncio
exports.updateAnuncio = async (req, res) => {
  try {
    // Verificar que el anuncio existe
    let anuncio = await Anuncio.findById(req.params.id);
    
    if (!anuncio) {
      return res.status(404).json({
        success: false,
        message: 'Anuncio no encontrado'
      });
    }
    
    // Verificar permisos
    if (req.user.tipo === 'ANUNCIANTE' && anuncio.anuncianteId.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'No tienes permiso para actualizar este anuncio'
      });
    }
    
    // Verificar que el anuncio está en un estado que permite modificaciones
    const estadosModificables = ['BORRADOR', 'PENDIENTE_APROBACION', 'RECHAZADO'];
    if (!estadosModificables.includes(anuncio.estado)) {
      return res.status(400).json({
        success: false,
        message: `No se puede modificar un anuncio en estado ${anuncio.estado}`
      });
    }
    
    // Campos que no se pueden actualizar directamente
    const restrictedFields = ['anuncianteId', 'canalId', 'tarifaId', 'estado', 'fechaCreacion', 'fechaPublicacion'];
    
    // Filtrar campos restringidos
    const filteredBody = Object.keys(req.body).reduce((obj, key) => {
      if (!restrictedFields.includes(key)) {
        obj[key] = req.body[key];
      }
      return obj;
    }, {});
    
    // Actualizar anuncio
    anuncio = await Anuncio.findByIdAndUpdate(
      req.params.id,
      filteredBody,
      {
        new: true,
        runValidators: true
      }
    );
    
    res.status(200).json({
      success: true,
      message: 'Anuncio actualizado exitosamente',
      data: anuncio
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al actualizar anuncio',
      error: error.message
    });
  }
};

// Enviar anuncio para aprobación
exports.submitAnuncio = async (req, res) => {
  try {
    // Verificar que el anuncio existe
    let anuncio = await Anuncio.findById(req.params.id);
    
    if (!anuncio) {
      return res.status(404).json({
        success: false,
        message: 'Anuncio no encontrado'
      });
    }
    
    // Verificar permisos
    if (req.user.tipo === 'ANUNCIANTE' && anuncio.anuncianteId.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'No tienes permiso para enviar este anuncio'
      });
    }
    
    // Verificar que el anuncio está en estado borrador
    if (anuncio.estado !== 'BORRADOR') {
      return res.status(400).json({
        success: false,
        message: 'Solo se pueden enviar anuncios en estado borrador'
      });
    }
    
    // Actualizar estado del anuncio
    anuncio.estado = 'PENDIENTE_APROBACION';
    await anuncio.save();
    
    res.status(200).json({
      success: true,
      message: 'Anuncio enviado para aprobación',
      data: anuncio
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al enviar anuncio para aprobación',
      error: error.message
    });
  }
};

// Aprobar anuncio
exports.approveAnuncio = async (req, res) => {
  try {
    // Verificar que el anuncio existe
    let anuncio = await Anuncio.findById(req.params.id);
    
    if (!anuncio) {
      return res.status(404).json({
        success: false,
        message: 'Anuncio no encontrado'
      });
    }
    
    // Verificar permisos (solo el creador del canal o admin puede aprobar)
    const canal = await Canal.findById(anuncio.canalId);
    
    if (req.user.tipo === 'CREADOR' && canal.creadorId.toString() !== req.user.id && req.user.tipo !== 'ADMINISTRADOR') {
      return res.status(403).json({
        success: false,
        message: 'No tienes permiso para aprobar este anuncio'
      });
    }
    
    // Verificar que el anuncio está pendiente de aprobación
    if (anuncio.estado !== 'PENDIENTE_APROBACION') {
      return res.status(400).json({
        success: false,
        message: 'Solo se pueden aprobar anuncios pendientes de aprobación'
      });
    }
    
    // Actualizar estado del anuncio
    anuncio.estado = 'APROBADO';
    await anuncio.save();
    
    // Añadir comentario si se proporcionó
    if (req.body.comentario) {
      anuncio.comentarios.push({
        usuario: req.user.id,
        texto: req.body.comentario
      });
      await anuncio.save();
    }
    
    res.status(200).json({
      success: true,
      message: 'Anuncio aprobado exitosamente',
      data: anuncio
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al aprobar anuncio',
      error: error.message
    });
  }
};

// Rechazar anuncio
exports.rejectAnuncio = async (req, res) => {
  try {
    // Verificar que el anuncio existe
    let anuncio = await Anuncio.findById(req.params.id);
    
    if (!anuncio) {
      return res.status(404).json({
        success: false,
        message: 'Anuncio no encontrado'
      });
    }
    
    // Verificar permisos (solo el creador del canal o admin puede rechazar)
    const canal = await Canal.findById(anuncio.canalId);
    
    if (req.user.tipo === 'CREADOR' && canal.creadorId.toString() !== req.user.id && req.user.tipo !== 'ADMINISTRADOR') {
      return res.status(403).json({
        success: false,
        message: 'No tienes permiso para rechazar este anuncio'
      });
    }
    
    // Verificar que el anuncio está pendiente de aprobación
    if (anuncio.estado !== 'PENDIENTE_APROBACION') {
      return res.status(400).json({
        success: false,
        message: 'Solo se pueden rechazar anuncios pendientes de aprobación'
      });
    }
    
    // Verificar que se proporcionó un motivo de rechazo
    if (!req.body.comentario) {
      return res.status(400).json({
        success: false,
        message: 'Debes proporcionar un motivo para el rechazo'
      });
    }
    
    // Actualizar estado del anuncio
    anuncio.estado = 'RECHAZADO';
    
    // Añadir comentario con motivo de rechazo
    anuncio.comentarios.push({
      usuario: req.user.id,
      texto: req.body.comentario
    });
    
    await anuncio.save();
    
    res.status(200).json({
      success: true,
      message: 'Anuncio rechazado',
      data: anuncio
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al rechazar anuncio',
      error: error.message
    });
  }
};

// Programar publicación de anuncio
exports.scheduleAnuncio = async (req, res) => {
  try {
    // Verificar que el anuncio existe
    let anuncio = await Anuncio.findById(req.params.id);
    
    if (!anuncio) {
      return res.status(404).json({
        success: false,
        message: 'Anuncio no encontrado'
      });
    }
    
    // Verificar permisos
    const canal = await Canal.findById(anuncio.canalId);
    
    if (req.user.tipo === 'CREADOR' && canal.creadorId.toString() !== req.user.id && req.user.tipo !== 'ADMINISTRADOR') {
      return res.status(403).json({
        success: false,
        message: 'No tienes permiso para programar este anuncio'
      });
    }
    
    // Verificar que el anuncio está aprobado
    if (anuncio.estado !== 'APROBADO') {
      return res.status(400).json({
        success: false,
        message: 'Solo se pueden programar anuncios aprobados'
      });
    }
    
    // Verificar que se proporcionó una fecha de programación
    if (!req.body.fechaProgramada) {
      return res.status(400).json({
        success: false,
        message: 'Debes proporcionar una fecha de programación'
      });
    }
    
    // Verificar que la fecha es futura
    const fechaProgramada = new Date(req.body.fechaProgramada);
    if (fechaProgramada <= new Date()) {
      return res.status(400).json({
        success: false,
        message: 'La fecha de programación debe ser futura'
      });
    }
    
    // Actualizar estado y fecha programada
    anuncio.estado = 'PROGRAMADO';
    anuncio.fechaProgramada = fechaProgramada;
    await anuncio.save();
    
    res.status(200).json({
      success: true,
      message: 'Anuncio programado exitosamente',
      data: anuncio
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al programar anuncio',
      error: error.message
    });
  }
};

// Marcar anuncio como publicado
exports.publishAnuncio = async (req, res) => {
  try {
    // Verificar que el anuncio existe
    let anuncio = await Anuncio.findById(req.params.id);
    
    if (!anuncio) {
      return res.status(404).json({
        success: false,
        message: 'Anuncio no encontrado'
      });
    }
    
    // Verificar permisos
    const canal = await Canal.findById(anuncio.canalId);
    
    if (req.user.tipo === 'CREADOR' && canal.creadorId.toString() !== req.user.id && req.user.tipo !== 'ADMINISTRADOR') {
      return res.status(403).json({
        success: false,
        message: 'No tienes permiso para publicar este anuncio'
      });
    }
    
    // Verificar que el anuncio está programado o aprobado
    if (anuncio.estado !== 'PROGRAMADO' && anuncio.estado !== 'APROBADO') {
      return res.status(400).json({
        success: false,
        message: 'Solo se pueden publicar anuncios programados o aprobados'
      });
    }
    
    // Actualizar estado y fecha de publicación
    anuncio.estado = 'PUBLICADO';
    anuncio.fechaPublicacion = new Date();
    
    // Actualizar metadatos si se proporcionaron
    if (req.body.idPublicacionExterna) {
      anuncio.metadatos.idPublicacionExterna = req.body.idPublicacionExterna;
    }
    
    if (req.body.urlPublicacion) {
      anuncio.metadatos.urlPublicacion = req.body.urlPublicacion;
    }
    
    if (req.body.capturaPublicacion) {
      anuncio.metadatos.capturaPublicacion = req.body.capturaPublicacion;
    }
    
    await anuncio.save();
    
    res.status(200).json({
      success: true,
      message: 'Anuncio marcado como publicado',
      data: anuncio
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al marcar anuncio como publicado',
      error: error.message
    });
  }
};

// Verificar publicación de anuncio
exports.verifyAnuncio = async (req, res) => {
  try {
    // Verificar que el anuncio existe
    let anuncio = await Anuncio.findById(req.params.id);
    
    if (!anuncio) {
      return res.status(404).json({
        success: false,
        message: 'Anuncio no encontrado'
      });
    }
    
   <response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>