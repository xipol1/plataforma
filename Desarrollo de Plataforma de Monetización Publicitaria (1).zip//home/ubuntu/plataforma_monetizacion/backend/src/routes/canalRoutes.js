const express = require('express');
const router = express.Router();
const canalController = require('../controllers/canalController');
const auth = require('../middleware/auth');

// Middleware para verificar autenticación en todas las rutas
router.use(auth);

// Rutas para canales
router.route('/')
  .get(canalController.getCanales)
  .post(canalController.createCanal);

router.route('/:id')
  .get(canalController.getCanal)
  .put(canalController.updateCanal)
  .delete(canalController.deleteCanal);

// Rutas para verificación de canales
router.post('/:id/verificacion', canalController.iniciarVerificacion);

// Rutas para estadísticas de canales
router.get('/:id/estadisticas', canalController.getEstadisticas);

// Rutas para tarifas
router.route('/:id/tarifas')
  .post(canalController.addTarifa);

router.route('/:id/tarifas/:tarifaId')
  .put(canalController.updateTarifa)
  .delete(canalController.deleteTarifa);

module.exports = router;
