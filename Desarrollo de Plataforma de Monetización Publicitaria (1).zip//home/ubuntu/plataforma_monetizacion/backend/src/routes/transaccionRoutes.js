const express = require('express');
const router = express.Router();
const transaccionController = require('../controllers/transaccionController');
const auth = require('../middleware/auth');

// Middleware para verificar autenticación en todas las rutas
router.use(auth);

// Rutas para transacciones
router.route('/')
  .get(transaccionController.getTransacciones)
  .post(transaccionController.createTransaccion);

router.route('/:id')
  .get(transaccionController.getTransaccion);

// Rutas para actualizar estado de transacciones
router.put('/:id/estado', transaccionController.updateEstadoTransaccion);

// Rutas para retiros
router.post('/retiro', transaccionController.solicitarRetiro);

// Rutas para saldo
router.get('/saldo', transaccionController.getSaldo);

// Rutas para métodos de pago
router.get('/metodos-pago', transaccionController.getMetodosPago);
router.post('/metodos-pago', transaccionController.addMetodoPago);
router.delete('/metodos-pago/:id', transaccionController.deleteMetodoPago);

module.exports = router;
