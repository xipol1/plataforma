const express = require('express');
const router = express.Router();
const anuncioController = require('../controllers/anuncioController');
const auth = require('../middleware/auth');

// Middleware para verificar autenticación en todas las rutas
router.use(auth);

// Rutas para anuncios
router.route('/')
  .get(anuncioController.getAnuncios)
  .post(anuncioController.createAnuncio);

router.route('/:id')
  .get(anuncioController.getAnuncio)
  .put(anuncioController.updateAnuncio);

// Rutas para flujo de trabajo de anuncios
router.post('/:id/submit', anuncioController.submitAnuncio);
router.post('/:id/approve', anuncioController.approveAnuncio);
router.post('/:id/reject', anuncioController.rejectAnuncio);
router.post('/:id/schedule', anuncioController.scheduleAnuncio);
router.post('/:id/publish', anuncioController.publishAnuncio);
router.post('/:id/verify', anuncioController.verifyAnuncio);

// Rutas para estadísticas de anuncios
router.get('/:id/estadisticas', anuncioController.getEstadisticas);

module.exports = router;
