const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const auth = require('../middleware/auth');

// Rutas públicas
router.post('/register', authController.register);
router.post('/login', authController.login);
router.post('/forgot-password', authController.forgotPassword);
router.post('/reset-password/:token', authController.resetPassword);

// Rutas protegidas
router.get('/me', auth, authController.getMe);
router.put('/update-profile', auth, authController.updateMe);
router.put('/update-password', auth, authController.updatePassword);

module.exports = router;
