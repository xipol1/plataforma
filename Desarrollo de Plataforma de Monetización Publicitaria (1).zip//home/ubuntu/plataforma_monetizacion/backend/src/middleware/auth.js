const jwt = require('jsonwebtoken');
const config = require('../config/config');
const User = require('../models/User');

// Middleware para verificar el token JWT
exports.protect = async (req, res, next) => {
  try {
    let token;
    
    // Verificar si el token está en los headers
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
      token = req.headers.authorization.split(' ')[1];
    }
    
    // Verificar si el token existe
    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'No estás autorizado para acceder a este recurso'
      });
    }
    
    // Verificar el token
    const decoded = jwt.verify(token, config.JWT_SECRET);
    
    // Buscar el usuario
    const user = await User.findById(decoded.id);
    
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'El usuario asociado a este token ya no existe'
      });
    }
    
    // Verificar si el usuario está activo
    if (user.estado !== 'ACTIVO') {
      return res.status(401).json({
        success: false,
        message: 'Tu cuenta no está activa. Contacta al soporte.'
      });
    }
    
    // Añadir el usuario a la request
    req.user = user;
    next();
  } catch (error) {
    return res.status(401).json({
      success: false,
      message: 'Token inválido o expirado'
    });
  }
};

// Middleware para restringir acceso según el tipo de usuario
exports.restrictTo = (...tipos) => {
  return (req, res, next) => {
    if (!tipos.includes(req.user.tipo)) {
      return res.status(403).json({
        success: false,
        message: 'No tienes permiso para realizar esta acción'
      });
    }
    next();
  };
};

// Middleware para verificar propiedad de un recurso
exports.checkOwnership = (model, paramIdField) => {
  return async (req, res, next) => {
    try {
      const resourceId = req.params[paramIdField];
      const resource = await model.findById(resourceId);
      
      if (!resource) {
        return res.status(404).json({
          success: false,
          message: 'Recurso no encontrado'
        });
      }
      
      // Verificar si el usuario es propietario del recurso
      // Esto asume que el recurso tiene un campo creadorId o anuncianteId
      const ownerId = resource.creadorId || resource.anuncianteId;
      
      if (ownerId && ownerId.toString() !== req.user.id && req.user.tipo !== 'ADMINISTRADOR') {
        return res.status(403).json({
          success: false,
          message: 'No tienes permiso para acceder a este recurso'
        });
      }
      
      // Añadir el recurso a la request
      req.resource = resource;
      next();
    } catch (error) {
      return res.status(500).json({
        success: false,
        message: 'Error al verificar propiedad del recurso',
        error: error.message
      });
    }
  };
};
