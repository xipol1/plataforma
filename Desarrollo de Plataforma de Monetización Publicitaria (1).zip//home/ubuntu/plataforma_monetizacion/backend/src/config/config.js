require('dotenv').config();

module.exports = {
  // Entorno de la aplicación
  NODE_ENV: process.env.NODE_ENV || 'development',
  
  // Configuración del servidor
  PORT: process.env.PORT || 5000,
  API_PREFIX: '/api/v1',
  
  // Configuración de la base de datos
  MONGODB_URI: process.env.MONGODB_URI || 'mongodb://localhost:27017/plataforma_monetizacion',
  
  // Configuración de JWT
  JWT_SECRET: process.env.JWT_SECRET || 'tu_secreto_jwt_super_seguro',
  JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN || '7d',
  
  // Configuración de CORS
  CORS_ORIGIN: process.env.CORS_ORIGIN || '*',
  
  // Configuración de servicios externos
  TELEGRAM_BOT_TOKEN: process.env.TELEGRAM_BOT_TOKEN,
  WHATSAPP_API_KEY: process.env.WHATSAPP_API_KEY,
  META_APP_ID: process.env.META_APP_ID,
  META_APP_SECRET: process.env.META_APP_SECRET,
  DISCORD_BOT_TOKEN: process.env.DISCORD_BOT_TOKEN,
  
  // Configuración de pagos
  STRIPE_SECRET_KEY: process.env.STRIPE_SECRET_KEY,
  STRIPE_WEBHOOK_SECRET: process.env.STRIPE_WEBHOOK_SECRET,
  PAYPAL_CLIENT_ID: process.env.PAYPAL_CLIENT_ID,
  PAYPAL_CLIENT_SECRET: process.env.PAYPAL_CLIENT_SECRET,
  
  // Configuración de correo electrónico
  EMAIL_SERVICE: process.env.EMAIL_SERVICE || 'gmail',
  EMAIL_USER: process.env.EMAIL_USER,
  EMAIL_PASSWORD: process.env.EMAIL_PASSWORD,
  
  // Configuración de almacenamiento
  STORAGE_TYPE: process.env.STORAGE_TYPE || 'local', // 'local', 's3', 'gcs'
  S3_BUCKET_NAME: process.env.S3_BUCKET_NAME,
  S3_ACCESS_KEY: process.env.S3_ACCESS_KEY,
  S3_SECRET_KEY: process.env.S3_SECRET_KEY,
  
  // Configuración de comisiones
  PLATFORM_COMMISSION_RATE: process.env.PLATFORM_COMMISSION_RATE || 0.10, // 10% por defecto
};
