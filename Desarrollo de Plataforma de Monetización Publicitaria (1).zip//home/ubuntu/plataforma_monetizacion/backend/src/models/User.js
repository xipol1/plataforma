const mongoose = require('mongoose');
const bcrypt = require('bcrypt');

const userSchema = new mongoose.Schema({
  tipo: {
    type: String,
    enum: ['CREADOR', 'ANUNCIANTE', 'ADMINISTRADOR'],
    required: true
  },
  email: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    lowercase: true
  },
  password: {
    type: String,
    required: true,
    minlength: 8
  },
  nombre: {
    type: String,
    required: true,
    trim: true
  },
  apellido: {
    type: String,
    required: true,
    trim: true
  },
  telefono: {
    type: String,
    trim: true
  },
  pais: {
    type: String,
    trim: true
  },
  idioma: {
    type: String,
    default: 'es'
  },
  fechaRegistro: {
    type: Date,
    default: Date.now
  },
  estado: {
    type: String,
    enum: ['ACTIVO', 'INACTIVO', 'SUSPENDIDO', 'VERIFICANDO'],
    default: 'VERIFICANDO'
  },
  metodosPago: [{
    tipo: {
      type: String,
      enum: ['TARJETA', 'PAYPAL', 'TRANSFERENCIA', 'CRIPTO']
    },
    detalles: {
      type: Object
    },
    predeterminado: {
      type: Boolean,
      default: false
    }
  }],
  configuracionNotificaciones: {
    email: {
      type: Boolean,
      default: true
    },
    push: {
      type: Boolean,
      default: true
    },
    sms: {
      type: Boolean,
      default: false
    }
  },
  resetPasswordToken: String,
  resetPasswordExpire: Date
}, {
  timestamps: true
});

// Middleware para encriptar la contraseña antes de guardar
userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) {
    return next();
  }
  
  try {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error) {
    next(error);
  }
});

// Método para comparar contraseñas
userSchema.methods.comparePassword = async function(candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

// Método para generar token de restablecimiento de contraseña
userSchema.methods.createPasswordResetToken = function() {
  const resetToken = crypto.randomBytes(32).toString('hex');
  
  this.resetPasswordToken = crypto
    .createHash('sha256')
    .update(resetToken)
    .digest('hex');
    
  this.resetPasswordExpire = Date.now() + 10 * 60 * 1000; // 10 minutos
  
  return resetToken;
};

const User = mongoose.model('User', userSchema);

module.exports = User;
