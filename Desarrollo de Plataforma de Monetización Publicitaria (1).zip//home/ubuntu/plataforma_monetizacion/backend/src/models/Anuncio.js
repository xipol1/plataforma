const mongoose = require('mongoose');

const anuncioSchema = new mongoose.Schema({
  anuncianteId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  canalId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Canal',
    required: true
  },
  tarifaId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Tarifa',
    required: true
  },
  titulo: {
    type: String,
    required: true,
    trim: true
  },
  contenido: {
    texto: {
      type: String,
      required: true
    },
    imagenes: [{
      url: String,
      descripcion: String
    }],
    enlaces: [{
      url: String,
      texto: String
    }],
    botones: [{
      texto: String,
      url: String,
      accion: String
    }]
  },
  estado: {
    type: String,
    enum: ['BORRADOR', 'PENDIENTE_APROBACION', 'APROBADO', 'RECHAZADO', 'PROGRAMADO', 'PUBLICADO', 'COMPLETADO'],
    default: 'BORRADOR'
  },
  fechaCreacion: {
    type: Date,
    default: Date.now
  },
  fechaProgramada: Date,
  fechaPublicacion: Date,
  comentarios: [{
    usuario: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    texto: String,
    fecha: {
      type: Date,
      default: Date.now
    }
  }],
  estadisticas: {
    impresiones: {
      type: Number,
      default: 0
    },
    clics: {
      type: Number,
      default: 0
    },
    interacciones: {
      type: Number,
      default: 0
    },
    compartidos: {
      type: Number,
      default: 0
    }
  },
  metadatos: {
    redactadoPor: {
      type: String,
      enum: ['ANUNCIANTE', 'CREADOR', 'PLATAFORMA'],
      default: 'ANUNCIANTE'
    },
    idPublicacionExterna: String,
    urlPublicacion: String,
    capturaPublicacion: String
  }
}, {
  timestamps: true
});

// Índices para búsquedas eficientes
anuncioSchema.index({ anuncianteId: 1 });
anuncioSchema.index({ canalId: 1 });
anuncioSchema.index({ estado: 1 });
anuncioSchema.index({ fechaProgramada: 1 });

const Anuncio = mongoose.model('Anuncio', anuncioSchema);

module.exports = Anuncio;
