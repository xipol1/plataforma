const mongoose = require('mongoose');

const estadisticaSchema = new mongoose.Schema({
  entidadId: {
    type: mongoose.Schema.Types.ObjectId,
    required: true
  },
  tipoEntidad: {
    type: String,
    enum: ['CANAL', 'ANUNCIO'],
    required: true
  },
  periodo: {
    inicio: {
      type: Date,
      required: true
    },
    fin: {
      type: Date,
      required: true
    }
  },
  metricas: {
    impresiones: {
      type: Number,
      default: 0
    },
    alcance: {
      type: Number,
      default: 0
    },
    interacciones: {
      type: Number,
      default: 0
    },
    clics: {
      type: Number,
      default: 0
    },
    conversiones: {
      type: Number,
      default: 0
    },
    compartidos: {
      type: Number,
      default: 0
    },
    comentarios: {
      type: Number,
      default: 0
    },
    reacciones: {
      type: Number,
      default: 0
    }
  },
  tendencia: {
    crecimiento: Number,
    comparacionPeriodoAnterior: Number
  },
  desglose: {
    porDia: Object,
    porRegion: Object,
    porDemografia: Object,
    porDispositivo: Object
  },
  fuente: {
    type: String,
    enum: ['MANUAL', 'API', 'ESTIMADO'],
    default: 'ESTIMADO'
  }
}, {
  timestamps: true
});

// Índices para búsquedas eficientes
estadisticaSchema.index({ entidadId: 1, tipoEntidad: 1 });
estadisticaSchema.index({ 'periodo.inicio': 1, 'periodo.fin': 1 });

const Estadistica = mongoose.model('Estadistica', estadisticaSchema);

module.exports = Estadistica;
