const mongoose = require('mongoose');

const transaccionSchema = new mongoose.Schema({
  anuncioId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Anuncio',
    required: true
  },
  anuncianteId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  creadorId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  monto: {
    type: Number,
    required: true,
    min: 0
  },
  comision: {
    type: Number,
    required: true,
    min: 0
  },
  montoNeto: {
    type: Number,
    required: true,
    min: 0
  },
  moneda: {
    type: String,
    default: 'USD',
    required: true
  },
  estado: {
    type: String,
    enum: ['PENDIENTE', 'RETENIDO', 'COMPLETADO', 'REEMBOLSADO', 'FALLIDO'],
    default: 'PENDIENTE'
  },
  metodoPago: {
    tipo: {
      type: String,
      enum: ['TARJETA', 'PAYPAL', 'TRANSFERENCIA', 'CRIPTO'],
      required: true
    },
    detalles: {
      type: Object
    }
  },
  fechaCreacion: {
    type: Date,
    default: Date.now
  },
  fechaActualizacion: {
    type: Date,
    default: Date.now
  },
  comprobante: String,
  referenciaPago: String,
  notasInternas: String,
  metadatosPasarela: Object
}, {
  timestamps: true
});

// Índices para búsquedas eficientes
transaccionSchema.index({ anuncioId: 1 });
transaccionSchema.index({ anuncianteId: 1 });
transaccionSchema.index({ creadorId: 1 });
transaccionSchema.index({ estado: 1 });
transaccionSchema.index({ fechaCreacion: 1 });

const Transaccion = mongoose.model('Transaccion', transaccionSchema);

module.exports = Transaccion;
