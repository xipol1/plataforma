const mongoose = require('mongoose');

const canalSchema = new mongoose.Schema({
  creadorId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  plataforma: {
    type: String,
    enum: ['TELEGRAM', 'WHATSAPP', 'INSTAGRAM', 'FACEBOOK', 'DISCORD'],
    required: true
  },
  nombre: {
    type: String,
    required: true,
    trim: true
  },
  descripcion: {
    type: String,
    required: true,
    trim: true
  },
  categoria: [{
    type: String,
    required: true
  }],
  audiencia: {
    tamano: {
      type: Number,
      required: true
    },
    demografia: {
      edadMinima: Number,
      edadMaxima: Number,
      genero: {
        type: String,
        enum: ['TODOS', 'MASCULINO', 'FEMENINO', 'OTRO']
      },
      otros: Object
    },
    ubicacion: [{
      type: String
    }],
    intereses: [{
      type: String
    }]
  },
  metricas: {
    alcance: Number,
    engagement: Number,
    crecimiento: Number,
    ultimaActualizacion: {
      type: Date,
      default: Date.now
    }
  },
  verificado: {
    type: Boolean,
    default: false
  },
  fechaVerificacion: Date,
  estado: {
    type: String,
    enum: ['ACTIVO', 'INACTIVO', 'PENDIENTE', 'RECHAZADO'],
    default: 'PENDIENTE'
  },
  identificadorExterno: {
    type: String,
    trim: true
  },
  urlCanal: {
    type: String,
    trim: true
  },
  politicas: {
    contenidoPermitido: [String],
    contenidoProhibido: [String],
    tiempoRespuesta: Number, // en horas
    politicaReembolso: String
  }
}, {
  timestamps: true
});

// Índices para búsquedas eficientes
canalSchema.index({ plataforma: 1 });
canalSchema.index({ categoria: 1 });
canalSchema.index({ 'audiencia.tamano': 1 });
canalSchema.index({ 'audiencia.ubicacion': 1 });
canalSchema.index({ estado: 1 });
canalSchema.index({ verificado: 1 });

// Método para calcular puntuación del canal (similar a JuiceFlow o métricas de calidad)
canalSchema.methods.calcularPuntuacion = function() {
  const baseScore = this.audiencia.tamano / 1000; // Base por cada 1000 seguidores
  const engagementBonus = this.metricas.engagement * 2; // Bonus por engagement
  const verificationBonus = this.verificado ? 10 : 0; // Bonus por verificación
  
  return Math.min(100, baseScore + engagementBonus + verificationBonus);
};

const Canal = mongoose.model('Canal', canalSchema);

module.exports = Canal;
