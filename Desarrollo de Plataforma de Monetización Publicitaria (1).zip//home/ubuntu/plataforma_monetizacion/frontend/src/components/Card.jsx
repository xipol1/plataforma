import React from 'react';

const Card = ({ 
  children, 
  className = '', 
  hover = true,
  ...props 
}) => {
  const baseClasses = 'bg-white rounded-xl shadow-card p-6';
  const hoverClasses = hover ? 'hover:shadow-card-hover transition-shadow' : '';
  
  return (
    <div
      className={`${baseClasses} ${hoverClasses} ${className}`}
      {...props}
    >
      {children}
    </div>
  );
};

export default Card;
