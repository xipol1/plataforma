import React from 'react';

const Sidebar = ({ 
  items = [], 
  activeItem, 
  onItemClick,
  logo,
  user,
  onLogout,
  className = '',
  ...props 
}) => {
  return (
    <div className={`bg-white shadow-sm h-screen flex flex-col ${className}`} {...props}>
      {/* Logo y cabecera */}
      <div className="p-4 border-b">
        {logo || <span className="text-2xl font-bold text-primary-600">LOGO</span>}
      </div>
      
      {/* Elementos de navegación */}
      <nav className="flex-1 overflow-y-auto py-4">
        <ul className="space-y-1">
          {items.map((item) => (
            <li key={item.id}>
              <button
                onClick={() => onItemClick(item.id)}
                className={`
                  w-full flex items-center px-4 py-3 text-sm font-medium rounded-md
                  ${activeItem === item.id
                    ? 'bg-primary-50 text-primary-600'
                    : 'text-gray-700 hover:bg-gray-50 hover:text-gray-900'}
                `}
              >
                {item.icon && (
                  <span className="mr-3 h-5 w-5">{item.icon}</span>
                )}
                {item.label}
              </button>
            </li>
          ))}
        </ul>
      </nav>
      
      {/* Información del usuario */}
      {user && (
        <div className="p-4 border-t">
          <div className="flex items-center">
            {user.avatar ? (
              <img 
                src={user.avatar} 
                alt={user.name} 
                className="h-8 w-8 rounded-full"
              />
            ) : (
              <div className="h-8 w-8 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center">
                {user.name.charAt(0).toUpperCase()}
              </div>
            )}
            <div className="ml-3">
              <p className="text-sm font-medium text-gray-700">{user.name}</p>
              <p className="text-xs text-gray-500">{user.email}</p>
            </div>
            {onLogout && (
              <button
                onClick={onLogout}
                className="ml-auto text-gray-400 hover:text-gray-500"
                title="Cerrar sesión"
              >
                <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                </svg>
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default Sidebar;
