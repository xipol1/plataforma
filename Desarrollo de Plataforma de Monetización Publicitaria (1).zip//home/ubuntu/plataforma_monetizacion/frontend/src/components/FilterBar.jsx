import React from 'react';

const FilterBar = ({ 
  filters = [], 
  onFilterChange,
  className = '',
  ...props 
}) => {
  return (
    <div className={`bg-white rounded-lg shadow-sm p-4 mb-6 ${className}`} {...props}>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filters.map((filter) => (
          <div key={filter.id} className="flex flex-col">
            <label htmlFor={filter.id} className="block text-sm font-medium text-gray-700 mb-1">
              {filter.label}
            </label>
            
            {filter.type === 'select' && (
              <select
                id={filter.id}
                name={filter.id}
                value={filter.value}
                onChange={(e) => onFilterChange(filter.id, e.target.value)}
                className="form-input"
              >
                {filter.options.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            )}
            
            {filter.type === 'text' && (
              <input
                type="text"
                id={filter.id}
                name={filter.id}
                value={filter.value}
                onChange={(e) => onFilterChange(filter.id, e.target.value)}
                placeholder={filter.placeholder}
                className="form-input"
              />
            )}
            
            {filter.type === 'date' && (
              <input
                type="date"
                id={filter.id}
                name={filter.id}
                value={filter.value}
                onChange={(e) => onFilterChange(filter.id, e.target.value)}
                className="form-input"
              />
            )}
            
            {filter.type === 'range' && (
              <div className="flex items-center space-x-2">
                <input
                  type="number"
                  id={`${filter.id}-min`}
                  name={`${filter.id}-min`}
                  value={filter.value[0]}
                  onChange={(e) => onFilterChange(filter.id, [e.target.value, filter.value[1]])}
                  placeholder="Mín"
                  className="form-input w-full"
                />
                <span className="text-gray-500">-</span>
                <input
                  type="number"
                  id={`${filter.id}-max`}
                  name={`${filter.id}-max`}
                  value={filter.value[1]}
                  onChange={(e) => onFilterChange(filter.id, [filter.value[0], e.target.value])}
                  placeholder="Máx"
                  className="form-input w-full"
                />
              </div>
            )}
          </div>
        ))}
      </div>
      
      <div className="mt-4 flex justify-end">
        <button
          type="button"
          onClick={() => onFilterChange('reset')}
          className="mr-2 px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
        >
          Limpiar filtros
        </button>
        <button
          type="button"
          onClick={() => onFilterChange('apply')}
          className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700"
        >
          Aplicar filtros
        </button>
      </div>
    </div>
  );
};

export default FilterBar;
