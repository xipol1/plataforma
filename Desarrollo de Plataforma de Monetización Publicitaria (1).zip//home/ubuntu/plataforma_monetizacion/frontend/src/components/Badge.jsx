import React from 'react';

const Badge = ({ 
  children, 
  variant = 'info', 
  className = '', 
  ...props 
}) => {
  const baseClasses = 'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium';
  
  const variantClasses = {
    success: 'bg-green-100 text-green-800',
    warning: 'bg-yellow-100 text-yellow-800',
    error: 'bg-red-100 text-red-800',
    info: 'bg-blue-100 text-blue-800',
    gray: 'bg-gray-100 text-gray-800',
    primary: 'bg-primary-100 text-primary-800',
    secondary: 'bg-secondary-100 text-secondary-800',
  };
  
  return (
    <span
      className={`${baseClasses} ${variantClasses[variant] || variantClasses.info} ${className}`}
      {...props}
    >
      {children}
    </span>
  );
};

export default Badge;
