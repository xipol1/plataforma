import React from 'react';

const ActivityFeed = ({ 
  activities = [], 
  title = 'Actividad Reciente',
  emptyMessage = 'No hay actividades recientes',
  maxItems = 5,
  viewAllLink,
  className = '',
  ...props 
}) => {
  return (
    <div className={`bg-white rounded-xl shadow-card p-6 ${className}`} {...props}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-medium text-gray-900">{title}</h3>
        {viewAllLink && (
          <a href={viewAllLink} className="text-sm text-primary-600 hover:text-primary-800">
            Ver todo
          </a>
        )}
      </div>
      
      {activities.length === 0 ? (
        <p className="text-gray-500 text-center py-4">{emptyMessage}</p>
      ) : (
        <ul className="space-y-4">
          {activities.slice(0, maxItems).map((activity, index) => (
            <li key={index} className="flex items-start">
              {activity.icon && (
                <div className="flex-shrink-0 mr-3">
                  {activity.icon}
                </div>
              )}
              <div className="flex-1 min-w-0">
                <p className="text-sm text-gray-800">
                  {activity.content}
                </p>
                {activity.timestamp && (
                  <p className="text-xs text-gray-500 mt-1">
                    {activity.timestamp}
                  </p>
                )}
              </div>
              {activity.action && (
                <div className="ml-3">
                  {activity.action}
                </div>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default ActivityFeed;
